// Vercel API (CommonJS) → loads ESM backend via dynamic import
module.exports = async (req, res) => {
  try {
    const { runDeepResearch } = await import('../../backend/dist/services/research/engine.js');
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
    const body = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {});
    const { companyUrl = '', companyName = '', notes = '' } = body;
    const result = await runDeepResearch({ companyUrl, companyName, notes });
    return res.status(200).json(result);
  } catch (err) {
    console.error('research/run error', err);
    return res.status(500).json({ error: 'Research run failed', details: (err && err.message) || String(err) });
  }
};
