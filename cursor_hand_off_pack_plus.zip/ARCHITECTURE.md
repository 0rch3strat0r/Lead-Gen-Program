# Lead Gen Program – Cursor Hand‑Off (PLUS)

This pack includes **everything Cursor needs** to wire in your Horsemen analysis and all templates
(Executive Brief, Vetting, ROI, Engagement Process, NEPQ intros/cheat sheets).

**Single source of truth** = this repo.
- Backend: **ESM** modules
- API routes: **CommonJS** wrappers that `await import()` backend
- Templates: anchored in `/frontend/templates` with a manifest
- NEPQ library: indexed under `/docs/nepq/` with usage guidelines

## Repo Layout (key)
```
/public/                            # your landing/dashboard (from AI Command Center)
/public/js/research.js              # optional fetch hook → /api/research/run
/frontend/templates/                # MASTER templates (anchor only)
/frontend/templates/manifest.json   # Template registry + slots
/backend/src/services/templates/    # loader + renderer stubs
/backend/src/services/nepq/         # NEPQ accessor stubs
/backend/src/services/research/     # engine, score, passes/*
/api/research/*.js                  # API wrappers
/docs/HORSEMEN_IMPLEMENTATION.md    # how each pass should work
/docs/NEPQ_LIBRARY_INDEX.md         # what NEPQ assets exist and how to use them
/docs/TEMPLATE_SLOTS.md             # placeholder map for each template
vercel.json
.env.example
ARCHITECTURE.md
```

## Hard Rules (to avoid CJS/ESM breakage)
1) Do **not** flip `package.json` type.
2) Backend = **ESM** only (import/export). No `require()` in backend.
3) API = **.js (CommonJS)** only, use `await import()` to load ESM.
4) Only edit **master templates** in `/frontend/templates`. Never edit generated outputs.
5) Other AIs (GPT‑5/Claude) produce **single files** targeting paths in this layout.

## Cursor To‑Do (minimal)
- Implement `passes/*.ts` with real logic.
- Flesh out `score.ts` (scoring heuristics).
- Replace placeholder templates with your master HTMLs.
- Use `templates/loader.ts` + `renderer.ts` to merge data → HTML.
- Use `nepq/index.ts` to pull scripts/cheat‑sheets into outputs when needed.
