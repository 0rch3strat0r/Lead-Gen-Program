export type ResearchOptions = { companyUrl?: string; companyName?: string; notes?: string; };
export type ResearchFinding = { title: string; detail: string; confidence?: number; tags?: string[]; };
export type ResearchResult = { jobId: string; summary: string; findings: ResearchFinding[]; meta?: Record<string, any>; };

import { brodyPass } from './passes/brody.js';
import { karenPass } from './passes/karen.js';
import { kevinPass } from './passes/kevin.js';
import { durinPass } from './passes/durin.js';
import { pinkoPass } from './passes/pinko.js';
import { scoreOpportunity } from './score.js';

export async function runDeepResearch(opts: ResearchOptions): Promise<ResearchResult> {
  const jobId = `job_${{Date.now()}}`;
  const {{ companyUrl = '', companyName = '', notes = '' }} = opts || {{}};

  // Run passes (Cursor to implement real logic)
  const passes = await Promise.all([
    brodyPass({{ companyUrl, companyName }}),
    karenPass({{ companyUrl, companyName }}),
    kevinPass({{ companyUrl, companyName }}),
    durinPass({{ companyUrl, companyName }}),
    pinkoPass({{ companyUrl, companyName }}),
  ]);

  const findings: ResearchFinding[] = passes.flat();
  const scored = scoreOpportunity({{ companyUrl, companyName, findings }});

  const summary = `Deep research created ${{findings.length}} findings for ${{companyName || companyUrl || "the target"}}. Score: ${{scored.score}}`;
  return {{ jobId, summary, findings, meta: {{ notes, score: scored.score, reasons: scored.reasons }} }};
}
