# Lead Gen Program – Cursor Hand‑Off

**Single source of truth** lives in this repo. Cursor does all coding; this pack provides file stubs and boundaries.

## Layout
```
/public/js/research.js                 # minimal API caller (Cursor can replace)
/frontend/templates/*.html             # anchor templates (replace with your master files)
/api/research/run.js                   # CJS wrapper → dynamic import ESM backend
/api/research/jobs.js                  # (stub) list/inspect research jobs
/backend/src/services/research/engine.ts   # orchestrator (ESM)
/backend/src/services/research/score.ts    # scoring helper (ESM)
/backend/src/services/research/passes/*.ts # Horsemen stubs (ESM)
vercel.json
.env.example
```

## Hard Rules
1) Backend is **ESM** only. No `require()`.
2) API routes are **.js (CommonJS)** that `await import()` backend ESM.
3) Do not flip `package.json` type mid-flight.
4) Templates in `/frontend/templates` are the **anchor**. Replace placeholders with your master templates; do not edit generated outputs.

## API Contract (v0)
- `POST /api/research/run` → body: `{ companyUrl?, companyName?, notes? }`
  returns `{ jobId, summary, findings[], meta }`
- `GET /api/research/jobs` → returns `{ jobs: [] }` (stub)

## Cursor Tasks (suggested)
- Implement each pass in `/passes/` and wire into `engine.ts`.
- Flesh out `score.ts` and call it from `engine.ts`.
- Replace `/frontend/templates/*.html` with the real master templates.
- If needed, enhance `/public/js/research.js` to render results into your dashboard.
