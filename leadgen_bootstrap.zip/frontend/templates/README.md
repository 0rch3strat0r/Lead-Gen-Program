# Templates – How to Use
Place your master HTML/NEPQ templates here:

- `exec_brief_template.html`
- `company_vetting_template.html`
- `ai_revenue_roi_plan.html`
- `ai_consult_master_template.html`
- `ai_engagement_process_detailed.html`
- `ai_vs_fte_pitch_template_v2.html`

**Anchor rule:** only edit master files here. All generated outputs should be derived from these, never edited directly.
